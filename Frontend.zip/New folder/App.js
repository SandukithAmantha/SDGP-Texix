import { StatusBar } from 'expo-status-bar';
import React, {Component} from 'react';
import { StyleSheet, Text, View, TextInput, Button, Image } from 'react-native';

export default class App extends React.Component {
  render () {
    return (
      <View style={styles.container}>
      <Image
      style={styles.logo}
      source= {require('./assets/Logo.png')} />
      <Text style = {styles.description}>Sinhala Handwritten Character Mistakes Finder</Text>
      <Text style = {styles.login}>Member Login</Text>
      <StatusBar style="auto" />
      <View>
      <TextInput style={styles.input}
       placeholder='username or email'
       placeholderTextColor='rgba(255,255,255,0.7)' >
      </TextInput>
      <TextInput style={styles.input}
       placeholder='password'
       placeholderTextColor='rgba(255,255,255,0.7)'>
      </TextInput>
      <Button title = 'login'>
      </Button>
      </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#3498db',
    alignItems: 'center',
    justifyContent: 'center',
  },

  login: {
    marginTop: 30,
    fontWeight: 'bold',
    fontSize: 30,
  },

  logo: {
    width:100,
    height:100,
  },

  description: {
   marginTop: -20,
   color: '#fff',
   width: 320,
   textAlign: 'center',
   opacity: 0.7, 
  },

  input: {
    height: 40,
    backgroundColor: 'rgba(255,255,255,0.2)',
    width:300,
    marginBottom: 20,
    color: '#fff',
    paddingHorizontal: 10
  },
  
});
